package mvc;

public interface Observateur {

	public void actualiser(Sujet s);

}
